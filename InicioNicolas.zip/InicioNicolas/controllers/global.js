import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.8.1/firebase-app.js';
import {
  getAuth,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  signInWithPopup,
  GoogleAuthProvider,
  createUserWithEmailAndPassword,
  sendSignInLinkToEmail,
  FacebookAuthProvider,
  sendPasswordResetEmail,
  deleteUser
} from 'https://www.gstatic.com/firebasejs/10.8.1/firebase-auth.js';

const firebaseConfig = {
  apiKey: "AIzaSyDr9g2wEfqzQgCfeP_TcOSfAbNq3mRU5TU",
  authDomain: "desarrollonube-73c6f.firebaseapp.com",
  projectId: "desarrollonube-73c6f",
  storageBucket: "desarrollonube-73c6f.appspot.com",
  messagingSenderId: "179060021824",
  appId: "1:179060021824:web:02db7b70b24cda321adda5",
  measurementId: "G-0XW5V553HY"
};

// Inicializar Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const user = auth.currentUser;

const provider = new GoogleAuthProvider();

export const signInWithGoogle = () => signInWithPopup(auth, provider);

// Método de inicio de sesión con correo y contraseña
export const loginvalidation = (email, password) =>
  signInWithEmailAndPassword(auth, email, password);

// Método de cierre de sesión
export const logout = () => signOut(auth);

// Estado del usuario
export function userstate() {
  onAuthStateChanged(auth, (user) => {
    if (user) {
      const uid = user.uid;
      console.log(uid);
    } else {
      window.location.href = "../index.html";
    }
  });
}

const providerFacebook = new FacebookAuthProvider();
// Iniciando con Facebook
export const popup_facebook = () =>
  signInWithPopup(auth, providerFacebook)

//enviar correo verificacion registro
const actionCodeSettings = {
  url: 'https://nicolas.github.io/ApiClaseWeb/index.html',
  handleCodeInApp: true
}
export const correoVerifi = (email) =>
  sendSignInLinkToEmail(auth, email, actionCodeSettings)
    .then(() => {
      alert("Correo de verificación enviado correctamente.")
    })
    .catch((error) => {
      alert("Error al enviar el correo de verificación: " + error)
    })

//regist
export const registerMail = (email, password) =>
  createUserWithEmailAndPassword(auth, email, password)

//recovery
export const recovery = (email) =>
  sendPasswordResetEmail(auth, email)

//borrar
export const borrar_account = () =>
  deleteUser(user)